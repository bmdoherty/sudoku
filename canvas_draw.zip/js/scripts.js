var app = (function() {
    var commands = ["clear", "circle", "rectangle", "line", "fill"];
    var canvas = document.getElementById("canvas");
    var ctx = canvas.getContext("2d");

    function isValidCommand(command) {
        return commands.indexOf(command) > -1;
    }

    function showValidationError(id, message) {
        document.getElementById(id).innerHTML = message;
        document.getElementById(id).style.display = "inline";
    }

    function addHistory(id, message) {
        document.getElementById(id).innerHTML = document.getElementById(id).innerHTML + "<br>" + message;
    }

    function clearError(id) {
        document.getElementById(id).innerHTML = "";
        document.getElementById(id).style.display = "none";
    }

    function checkIntegers(args) {
        for (arg of args) {
            // for purposes of this assuming inputs are integers
            if (!Number.isInteger(parseInt(arg, 10))) {
                showValidationError("error", `${arg} is not a valid integer`);
                return false;
            }
        }

        return true;
    }

    checkInput = function(input) {
        clearError("error");
        let inputArray = input.trim().split(" ");
        let command = inputArray.shift();
        let arguments = inputArray;
        let color = arguments.pop();

        // check against known commands
        if (!isValidCommand(command)) {
            showValidationError(
                "error",
                `${command} is an invalid command, valid commands are [ ${commands.join(", ")} ]`
            );

            return false;
        }

        // check arguments
        switch (command) {
            case "clear":
                if (arguments.length !== 0 || typeof color === "undefined") {
                    showValidationError("error", `invalid arguments, clear command takes one argument, ['colour']`);
                    return false;
                }

                if (!validTextColour(color)) {
                    return false;
                }

                ctx.fillStyle = color;
                ctx.fillRect(0, 0, canvas.width, canvas.height);

                break;

            case "circle":
                if (arguments.length !== 3 || typeof color === "undefined") {
                    showValidationError(
                        "error",
                        `invalid arguments, circle command takes four arguments, ['x' 'y' 'radius' 'colour']`
                    );
                    return false;
                }

                if (!checkIntegers(arguments)) {
                    return false;
                }

                if (!validTextColour(color)) {
                    return false;
                }

                ctx.beginPath();
                ctx.arc(arguments[0], arguments[1], arguments[2], 0, 2 * Math.PI, false);
                ctx.lineWidth = 5;
                ctx.strokeStyle = color;
                ctx.stroke();

                break;

            case "rectangle":
                if (arguments.length !== 4 || typeof color === "undefined") {
                    showValidationError(
                        "error",
                        `invalid arguments, rectangle command takes five arguments, ['x' 'y' 'w' 'h' 'colour']`
                    );
                    return false;
                }

                if (!checkIntegers(arguments)) {
                    return false;
                }

                if (!validTextColour(color)) {
                    return false;
                }

                ctx.rect(arguments[0], arguments[1], arguments[2], arguments[3]);
                ctx.lineWidth = 5;
                ctx.strokeStyle = color;
                ctx.stroke();

                break;

            case "line":
                if (arguments.length !== 4 || typeof color === "undefined") {
                    showValidationError(
                        "error",
                        `invalid arguments, line command takes five arguments, ['x1' 'y1' 'x2' 'y2' 'colour']`
                    );
                    return false;
                }

                if (!checkIntegers(arguments)) {
                    return false;
                }

                if (!validTextColour(color)) {
                    return false;
                }

                ctx.beginPath();
                ctx.moveTo(arguments[0], arguments[1]);
                ctx.lineTo(arguments[2], arguments[3]);
                ctx.strokeStyle = color;
                ctx.stroke();

                break;

            case "fill":
                if (arguments.length !== 2 || typeof color === "undefined") {
                    showValidationError(
                        "error",
                        `invalid arguments, fill command takes three arguments, ['x' 'y' 'colour']`
                    );
                    return false;
                }

                if (!checkIntegers(arguments)) {
                    return false;
                }

                if (!validTextColour(color)) {
                    return false;
                }
                let x = parseInt(arguments[0], 10);
                let y = parseInt(arguments[1], 10);

                let imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                let node = [x, y];
                let targetColor = getPixelColor(x, y, imageData);
                let replacementColor = colorToRGBA(color);

                floodFill(imageData, node, targetColor, replacementColor);
                ctx.putImageData(imageData, 0, 0);

                imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

                break;
            default:
                break;
        }

        addHistory("log", input);
    };

    function getPixelColor(x, y, imageData) {
        let pos = getPixelPosition(x, y, imageData);
        let data = imageData.data;

        let red = data[pos * 4];
        let green = data[pos * 4 + 1];
        let blue = data[pos * 4 + 2];
        let alpha = data[pos * 4 + 3];

        return [red, green, blue, alpha];
    }

    function floodFill(imageData, node, targetColor, replacementColor) {
        let maxHeight = canvas.height;
        let maxWidth = canvas.width;
        let seen = {};

        if (compare(targetColor, replacementColor)) {
            return false;
        }

        let q = [];

        let data = imageData.data;
        let i = getPixelPosition(node[0], node[1], imageData);

        data[i * 4] = replacementColor[0];
        data[i * 4 + 1] = replacementColor[1];
        data[i * 4 + 2] = replacementColor[2];
        data[i * 4 + 3] = replacementColor[3];
        ctx.putImageData(imageData, 0, 0);

        q.push(node);

        while (q.length !== 0) {
            let n = q.shift();
            let x = parseInt(n[0], 10);
            let y = parseInt(n[1], 10);
            let key = `${x}-${y}`;

            if (!seen[key]) {
                seen[key] = true;
                let i = getPixelPosition(x, y, imageData);

                // west;
                if (x + 1 < maxWidth) {
                    let wColor = getPixelColor(x + 1, y, imageData);
                    if (compare(targetColor, wColor)) {
                        data[i * 4] = replacementColor[0];
                        data[i * 4 + 1] = replacementColor[1];
                        data[i * 4 + 2] = replacementColor[2];
                        data[i * 4 + 3] = replacementColor[3];
                        q.push([x + 1, y]);
                    }
                }

                // east
                if (x - 1 > 0) {
                    let eColor = getPixelColor(x - 1, y, imageData);
                    if (compare(targetColor, eColor)) {
                        data[i * 4] = replacementColor[0];
                        data[i * 4 + 1] = replacementColor[1];
                        data[i * 4 + 2] = replacementColor[2];
                        data[i * 4 + 3] = replacementColor[3];
                        q.push([x - 1, y]);
                    }
                }

                // north
                if (y - 1 > 0) {
                    let nColor = getPixelColor(x, y - 1, imageData);
                    if (compare(targetColor, nColor)) {
                        data[i * 4] = replacementColor[0];
                        data[i * 4 + 1] = replacementColor[1];
                        data[i * 4 + 2] = replacementColor[2];
                        data[i * 4 + 3] = replacementColor[3];
                        q.push([x, y - 1]);
                    }
                }

                // south
                if (y + 1 < maxHeight) {
                    let sColor = getPixelColor(x, y + 1, imageData);
                    if (compare(targetColor, sColor)) {
                        data[i * 4] = replacementColor[0];
                        data[i * 4 + 1] = replacementColor[1];
                        data[i * 4 + 2] = replacementColor[2];
                        data[i * 4 + 3] = replacementColor[3];
                        q.push([x, y + 1]);
                    }
                }
            }
        }
    }

    function getPixelPosition(x, y, imageData) {
        return imageData.width * y + x;
    }

    function compare(a, b) {
        return a.length == b.length && a.every((v, i) => v === b[i]);
    }

    // using found library to check for valid colour
    function validTextColour(stringToTest) {
        if (stringToTest === "") {
            showValidationError("error", `\"\"  is not a valid colour`);
            return false;
        }
        if (stringToTest === "inherit") {
            return false;
        }
        if (stringToTest === "transparent") {
            return false;
        }

        var image = document.createElement("img");
        image.style.color = "rgb(0, 0, 0)";
        image.style.color = stringToTest;

        if (image.style.color !== "rgb(0, 0, 0)") {
            return true;
        }
        image.style.color = "rgb(255, 255, 255)";
        image.style.color = stringToTest;

        if (image.style.color === "rgb(255, 255, 255)") {
            showValidationError("error", `\"${stringToTest}\" is not a valid colour`);
            return false;
        }

        return true;
    }

    function colorToRGBA(color) {
        var cvs, ctx;
        cvs = document.createElement("canvas");
        cvs.height = 1;
        cvs.width = 1;
        ctx = cvs.getContext("2d");

        ctx.fillStyle = color;
        ctx.fillRect(0, 0, 1, 1);

        let data = ctx.getImageData(0, 0, 1, 1).data;

        let red = data[0];
        let green = data[1];
        let blue = data[2];
        let alpha = data[3];

        return [red, green, blue, alpha];
    }

    // fit canvas to its div wrapper, googled
    window.addEventListener("resize", fitToContainer, false);
    function fitToContainer(canvas) {
        if (canvas.style) {
            canvas.style.width = "100%";
            canvas.style.height = "100%";
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;
        }
    }

    fitToContainer(canvas);

    return this;
})();
